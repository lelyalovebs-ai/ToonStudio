# ToonStudio — Android 2D Animation Editor

A starter Android Studio project for an original 2D frame-by-frame drawing app.

## Included in this starter
- Kotlin + Jetpack Compose UI
- Drawing canvas with finger/stylus pointer input
- Brush size and color palette
- Frame timeline (add, select, delete)
- Onion-skin preview of the previous frame
- Basic playback preview and FPS selector
- Undo snapshots
- Save/load the current project as JSON in app-private storage

## Open in Android Studio
1. Extract the ZIP.
2. Open the `ToonStudio` folder in Android Studio.
3. Use JDK 17.
4. Allow Gradle sync to finish.
5. Run on an Android device or emulator (Android 8.0 / API 26 or newer).

## Save location
The Save button stores `toonstudio-project.json` in the app's private files directory. The Load button reads it back. This is app-internal storage, not a user-visible export file.

## Current limitations
This is a functional MVP foundation, not a feature-complete ToonSquid replacement. The first version does not yet include multiple independently editable layers, vector tools, pressure-sensitive brush dynamics, audio tracks, keyframe interpolation, GIF/MP4 export, or a full project browser. Those should be implemented as subsequent modules.

## Compatibility
The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01, compile/target SDK 35, and Java 17. Android Studio may offer a Gradle/plugin upgrade depending on its installed version.
