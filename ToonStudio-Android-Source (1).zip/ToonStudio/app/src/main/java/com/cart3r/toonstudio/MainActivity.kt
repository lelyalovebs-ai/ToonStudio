package com.cart3r.toonstudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.delay
import java.io.File
import kotlin.math.max

private val Bg = Color(0xFF17191E)
private val Panel = Color(0xFF22252C)
private val Accent = Color(0xFFB7A0FF)
private val Muted = Color(0xFF9298A5)

data class PointN(val x: Float, val y: Float)
data class StrokeData(
    val points: MutableList<PointN> = mutableListOf(),
    val color: Long = 0xFFFFFFFF,
    val width: Float = 5f
)
data class FrameData(val strokes: MutableList<StrokeData> = mutableListOf())
data class ToonProject(val name: String = "Untitled", val frames: MutableList<FrameData> = mutableListOf(FrameData()))

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ToonStudioApp() }
    }
}

@Composable
fun ToonStudioApp() {
    val context = LocalContext.current
    var project by remember { mutableStateOf(ToonProject()) }
    var selectedFrame by remember { mutableIntStateOf(0) }
    var selectedColor by remember { mutableLongStateOf(0xFFFFFFFF) }
    var brushSize by remember { mutableFloatStateOf(5f) }
    var onionSkin by remember { mutableStateOf(true) }
    var playing by remember { mutableStateOf(false) }
    var fps by remember { mutableIntStateOf(8) }
    var activeTab by remember { mutableStateOf("Кадры") }
    var undoStack by remember { mutableStateOf(listOf<String>()) }

    fun snapshot() {
        undoStack = undoStack + Gson().toJson(project)
        if (undoStack.size > 30) undoStack = undoStack.takeLast(30)
    }
    fun updateFrame(frame: FrameData) {
        val copy = project.frames.toMutableList()
        copy[selectedFrame] = frame
        project = project.copy(frames = copy)
    }

    LaunchedEffect(playing) {
        while (playing && project.frames.isNotEmpty()) {
            delay(1000L / fps.coerceAtLeast(1))
            selectedFrame = (selectedFrame + 1) % project.frames.size
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Column(
            Modifier.fillMaxSize().background(Bg).padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("TOONSTUDIO", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                    Text("2D ANIMATION WORKSPACE  •  v0.1", color = Muted, fontSize = 10.sp)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SmallAction("↶") {
                        if (undoStack.isNotEmpty()) {
                            project = Gson().fromJson(undoStack.last(), ToonProject::class.java)
                            undoStack = undoStack.dropLast(1)
                            selectedFrame = selectedFrame.coerceIn(0, project.frames.lastIndex.coerceAtLeast(0))
                        }
                    }
                    SmallAction("Save") {
                        runCatching {
                            File(context.filesDir, "toonstudio-project.json")
                                .writeText(Gson().toJson(project))
                        }
                    }
                    SmallAction("Load") {
                        runCatching {
                            val f = File(context.filesDir, "toonstudio-project.json")
                            if (f.exists()) {
                                project = Gson().fromJson(f.readText(), ToonProject::class.java)
                                selectedFrame = 0
                            }
                        }
                    }
                }
            }

            // Drawing workspace
            Box(
                Modifier.weight(1f).fillMaxWidth()
                    .background(Color(0xFF292C33), RoundedCornerShape(14.dp))
                    .padding(10.dp),
                contentAlignment = Alignment.Center
            ) {
                val frame = project.frames.getOrNull(selectedFrame) ?: FrameData()
                Canvas(
                    Modifier.fillMaxSize()
                        .background(Color(0xFFF4F1EA), RoundedCornerShape(5.dp))
                        .pointerInput(selectedFrame, selectedColor, brushSize, project.frames.size) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    snapshot()
                                    val current = project.frames[selectedFrame].copy(
                                        strokes = project.frames[selectedFrame].strokes.toMutableList()
                                    )
                                    val stroke = StrokeData(
                                        points = mutableListOf(PointN(
                                            (offset.x / size.width).coerceIn(0f, 1f),
                                            (offset.y / size.height).coerceIn(0f, 1f)
                                        )),
                                        color = selectedColor,
                                        width = brushSize
                                    )
                                    current.strokes.add(stroke)
                                    updateFrame(current)
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    val current = project.frames[selectedFrame].copy(
                                        strokes = project.frames[selectedFrame].strokes.toMutableList()
                                    )
                                    val last = current.strokes.lastOrNull() ?: return@detectDragGestures
                                    val updated = last.copy(points = last.points.toMutableList())
                                    updated.points.add(PointN(
                                        (change.position.x / size.width).coerceIn(0f, 1f),
                                        (change.position.y / size.height).coerceIn(0f, 1f)
                                    ))
                                    current.strokes[current.strokes.lastIndex] = updated
                                    updateFrame(current)
                                }
                            )
                        }
                ) {
                    fun drawStroke(stroke: StrokeData, alpha: Float = 1f) {
                        if (stroke.points.isEmpty()) return
                        val path = Path().apply {
                            moveTo(stroke.points.first().x * size.width, stroke.points.first().y * size.height)
                            stroke.points.drop(1).forEach {
                                lineTo(it.x * size.width, it.y * size.height)
                            }
                        }
                        drawPath(
                            path = path,
                            color = Color(stroke.color).copy(alpha = alpha),
                            style = androidx.compose.ui.graphics.drawscope.Stroke(
                                width = stroke.width * density,
                                cap = StrokeCap.Round,
                                join = StrokeJoin.Round
                            )
                        )
                        if (stroke.points.size == 1) {
                            val p = stroke.points.first()
                            drawCircle(Color(stroke.color).copy(alpha = alpha),
                                radius = stroke.width * density / 2,
                                center = Offset(p.x * size.width, p.y * size.height))
                        }
                    }
                    if (onionSkin && selectedFrame > 0) {
                        project.frames[selectedFrame - 1].strokes.forEach { drawStroke(it, 0.18f) }
                    }
                    frame.strokes.forEach { drawStroke(it) }
                }
                Text("FRAME ${selectedFrame + 1}", Modifier.align(Alignment.TopStart).padding(8.dp),
                    color = Color(0xFF777777), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }

            // Tools and brush palette
            Column(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Text("BRUSH", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text("${brushSize.toInt()} px", color = Color.White, fontSize = 11.sp)
                }
                Slider(value = brushSize, onValueChange = { brushSize = it }, valueRange = 1f..24f)
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp), verticalAlignment = Alignment.CenterVertically) {
                    listOf(0xFF17191E, 0xFFFFFFFF, 0xFFFF5C7A, 0xFFFFC857, 0xFF6ED6A5, 0xFF65A9FF, 0xFFB7A0FF).forEach { c ->
                        Box(
                            Modifier.size(27.dp)
                                .background(Color(c), RoundedCornerShape(50))
                                .border(if (selectedColor == c) 2.dp else 0.dp, Accent, RoundedCornerShape(50))
                                .clickable { selectedColor = c }
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    TextButton(onClick = {
                        snapshot()
                        updateFrame(FrameData())
                    }) { Text("Очистить") }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Onion skin", color = Muted, fontSize = 11.sp)
                        Switch(checked = onionSkin, onCheckedChange = { onionSkin = it })
                    }
                }
            }

            // Timeline
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Text("TIMELINE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${fps} FPS", color = Muted, fontSize = 10.sp)
                        TextButton(onClick = { fps = (fps % 24) + 1 }) { Text("FPS") }
                        TextButton(onClick = { playing = !playing }) { Text(if (playing) "❚❚" else "▶") }
                    }
                }
                LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    itemsIndexed(project.frames) { index, _ ->
                        Surface(
                            onClick = { selectedFrame = index; playing = false },
                            color = if (index == selectedFrame) Accent.copy(alpha = 0.28f) else Color(0xFF30343D),
                            shape = RoundedCornerShape(8.dp),
                            border = if (index == selectedFrame) androidx.compose.foundation.BorderStroke(1.dp, Accent) else null
                        ) {
                            Column(Modifier.width(55.dp).padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${index + 1}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("◆", color = Muted, fontSize = 9.sp)
                            }
                        }
                    }
                    item {
                        Surface(onClick = {
                            snapshot()
                            project = project.copy(frames = (project.frames + FrameData()).toMutableList())
                            selectedFrame = project.frames.lastIndex
                            playing = false
                        }, color = Color(0xFF383344), shape = RoundedCornerShape(8.dp)) {
                            Box(Modifier.size(width = 55.dp, height = 49.dp), contentAlignment = Alignment.Center) {
                                Text("+", color = Accent, fontSize = 22.sp)
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Кадр ${selectedFrame + 1} / ${project.frames.size}", color = Muted, fontSize = 10.sp)
                    TextButton(onClick = {
                        if (project.frames.size > 1) {
                            snapshot()
                            val list = project.frames.toMutableList()
                            list.removeAt(selectedFrame)
                            project = project.copy(frames = list)
                            selectedFrame = selectedFrame.coerceAtMost(list.lastIndex)
                        }
                    }) { Text("Удалить кадр") }
                }
            }
        }
    }
}

@Composable
private fun SmallAction(label: String, onClick: () -> Unit) {
    Surface(onClick = onClick, color = Panel, shape = RoundedCornerShape(8.dp)) {
        Text(label, Modifier.padding(horizontal = 10.dp, vertical = 8.dp), color = Color.White, fontSize = 11.sp)
    }
}
